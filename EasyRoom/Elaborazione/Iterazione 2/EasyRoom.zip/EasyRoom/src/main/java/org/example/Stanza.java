package org.example;

import java.util.Objects;

public class Stanza {
    private float prezzo;
    private int numeroStanza;
    private String nome;

    public Stanza (int numeroStanza, String nome, float prezzo){
        this.numeroStanza = numeroStanza;
        this.nome = nome;
        this.prezzo = prezzo;
    }
    public float getPrezzo() {
        return prezzo;
    }
    public int getNumero() {
        return numeroStanza;
    }
    public String getNome() {
        return nome;
    }
    public void setPrezzo(float prezzo){
        this.prezzo=prezzo;
    }

    public String toString(){
        return "ID stanza: " + numeroStanza + ", nome: " + nome + ", prezzo: " + prezzo;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Stanza stanza = (Stanza) o;
        return numeroStanza == stanza.numeroStanza &&
                Float.compare(stanza.prezzo, prezzo) == 0 &&
                Objects.equals(nome, stanza.nome);
    }

}
