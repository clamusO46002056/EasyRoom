package org.example;
import java.io.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.LinkedList;
import java.util.Objects;
import java.util.UUID;

public class EasyRoom {
    BufferedReader tastiera = new BufferedReader(new InputStreamReader(System.in));
    DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
    DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    int limite = 90;
    int massimoTorce = 25;
    int massimoIndizi = 30;
    float costoAttrezzo = 0.5f;
    private LinkedList<Giocatore> listaGiocatori;
    private LinkedList<Stanza> listaStanze;
    private LinkedList<Prenotazione> listaPrenotazioni;
    private LinkedList<Magazzino> listaRichieste;
    private static EasyRoom easyroom;
    public EasyRoom() {
        this.listaGiocatori = new LinkedList<>();
        this.listaStanze = new LinkedList<>();
        this.listaPrenotazioni = new LinkedList<>();
        this.listaRichieste = new LinkedList<>();
        loadUtentiRegistrati();
        loadStanze();
        loadPrenotazioni();
        loadRichieste();
    }
    public static EasyRoom getInstance(){
        if (easyroom==null) easyroom = new EasyRoom();
        return easyroom;
    }

    //Caricare in memoria i dati persistenti
    public void loadUtentiRegistrati() { // Creo in memoria la LinkedList dei giocatori già registrati
        listaGiocatori.clear();
        try {
            BufferedReader elencoGiocatoriLetto = new BufferedReader(new FileReader("listagiocatori.txt"));
            String linea;
            while ((linea = elencoGiocatoriLetto.readLine()) != null) {
                String[] datiGiocatore = linea.split(",");
                if (datiGiocatore.length >= 5) {
                    String nome = datiGiocatore[0];
                    String cognome = datiGiocatore[1];
                    String codiceFiscale = datiGiocatore[2];
                    String email = datiGiocatore[3];
                    LocalDate dataNascita = LocalDate.parse(datiGiocatore[4], dateFormatter);
                    listaGiocatori.add(new Giocatore(nome, cognome, codiceFiscale, email, dataNascita));
                }
            }
            elencoGiocatoriLetto.close();
            System.out.println("Elenco giocatori caricato in memoria");
        } catch (IOException e) {
            System.out.println("Si è verificato un errore nell'inserimento");
        }
    }
    public void loadStanze() {
        try {
            BufferedReader elencoStanzeLetto = new BufferedReader(new FileReader("listastanze.txt"));
            String linea;
            while ((linea = elencoStanzeLetto.readLine()) != null) {
                String[] datiStanza = linea.split(",");
                if (datiStanza.length >= 2) {
                    int idStanza = Integer.parseInt(datiStanza[0]);
                    String nome = datiStanza[1];
                    float prezzo = Float.parseFloat(datiStanza[2]);
                    listaStanze.add(new Stanza(idStanza, nome, prezzo));
                }
            }
            elencoStanzeLetto.close();
            System.out.println("Elenco stanze caricato in memoria");
        } catch (IOException e) {
            System.out.println("Si è verificato un errore nell'inserimento");
        }
    }
    public void loadPrenotazioni() {
        try {
            BufferedReader elencoPrenotazioniLetto = new BufferedReader(new FileReader("listaprenotazioni.txt"));
            String linea;
            while ((linea = elencoPrenotazioniLetto.readLine()) != null) {
                String[] datiPrenotazione = linea.split(",");
                if (datiPrenotazione.length >= 9) {
                    int idPrenotazione = Integer.parseInt(datiPrenotazione[0]);
                    int idStanza = Integer.parseInt(datiPrenotazione[1]);
                    String codiceFiscale1 = datiPrenotazione[2];
                    String codiceFiscale2 = datiPrenotazione[3];
                    LocalDate dataPrenotazione = LocalDate.parse(datiPrenotazione[4], dateFormatter);
                    LocalTime tempoInizio = LocalTime.parse(datiPrenotazione[5], timeFormatter);

                    LocalTime tempoFine = LocalTime.parse(datiPrenotazione[6], timeFormatter);
                    Attrezzatura richiestaAttrezzatura = new Attrezzatura(Integer.parseInt(datiPrenotazione[7]),Integer.parseInt(datiPrenotazione[8]));

                    float prezzo = Float.parseFloat(datiPrenotazione[9]);
                    Giocatore Utente1 = getUtenteCodiceFiscale(codiceFiscale1);
                    Giocatore Utente2 = getUtenteCodiceFiscale(codiceFiscale2);
                    Stanza stanzaPrenotata = getStanzaId(idStanza);
                    listaPrenotazioni.add(new Prenotazione(idPrenotazione, stanzaPrenotata, Utente1, Utente2, dataPrenotazione, tempoInizio, tempoFine, richiestaAttrezzatura, prezzo));
                }
            }
            elencoPrenotazioniLetto.close();
            System.out.println("Elenco prenotazioni caricato in memoria");
        } catch (IOException e) {
            System.out.println("Si è verificato un errore nell'inserimento");
        }
    }
    public void loadRichieste(){
        try {
            BufferedReader elencoRichiesteLetto = new BufferedReader(new FileReader("listarichieste.txt"));
            String linea;
            while ((linea = elencoRichiesteLetto.readLine()) != null) {
                String[] datiRichieste = linea.split(",");
                if (datiRichieste.length >= 2) {
                    LocalDate dataPrenotazione = LocalDate.parse(datiRichieste[0], dateFormatter);
                    int numeroTorce = Integer.parseInt(datiRichieste[1]);
                    int numeroIndizi = Integer.parseInt(datiRichieste[2]);
                    listaRichieste.add(new Magazzino(dataPrenotazione, numeroTorce, numeroIndizi));
                }
            }
            elencoRichiesteLetto.close();
            System.out.println("Elenco richieste caricato in memoria");
        } catch (IOException e) {
            System.out.println("Si è verificato un errore nell'inserimento delle richieste");
        }
    }

    //UC1
    public void inserisciUtente() {
         try {
             String nome;
             String cognome;
             String codiceFiscale;
             String email;
             String supporto;
             boolean giaPresente;
             System.out.println("Inserisci il nome del giocatore");
             nome = tastiera.readLine();
             System.out.println("Inserisci il cognome del giocatore");
             cognome = tastiera.readLine();
             System.out.println("Inserisci il codice fiscale del giocatore");
             codiceFiscale = tastiera.readLine();
             System.out.println("Inserisci la email del giocatore");
             email = tastiera.readLine();
             System.out.println("Inserisci la data di nascita del giocatore nel formato dd/MM/yyyy");
             supporto = tastiera.readLine();
             LocalDate dataNascita = LocalDate.parse(supporto, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
             giaPresente = verificaValiditaGiocatore(codiceFiscale);
             if(giaPresente){
                 System.out.println("Il giocatore è già presente nel sistema");
                 return;
             }
             Giocatore nuovoGiocatore = new Giocatore(nome, cognome, codiceFiscale, email, dataNascita);
             //Se non è presente lo aggiungo al file e ricreo la lista dei giocatori
             salvaGiocatoreSuFile(nuovoGiocatore);
             listaGiocatori.clear();
             loadUtentiRegistrati();

         } catch (IOException e) {
             System.out.println("Si è verificato un errore nell'inserimento");
         }

     }
    //UC2
    public void inserisciPrenotazione(){
        try{
            boolean esitoDurata = false;
            boolean stanzaLibera = false;
            int idStanza = -1;
            LocalDate dataPrenotazione = LocalDate.parse("01/01/1999", dateFormatter);
            LocalTime tempoInizio = LocalTime.parse("00:00", timeFormatter);
            LocalTime tempoFine = LocalTime.parse("00:00", timeFormatter);
            //Inserisco il primo utente e verifico la sua presenza nel sistema
            System.out.println("Inserisci il codice fiscale del primo partecipante");
            String codiceFiscale1 = tastiera.readLine();
            if(!verificaValiditaGiocatore(codiceFiscale1)){
                System.out.println("Il codice fiscale " + codiceFiscale1 + " non è associato a nessun giocatore del sistema");
                return;
            }
            //Inserisco il secondo utente e verifico la sua presenza nel sistema
            System.out.println("Inserisci il codice fiscale del secondo partecipante");
            String codiceFiscale2 = tastiera.readLine();
            if(!verificaValiditaGiocatore(codiceFiscale2)){
                System.out.println("Il codice fiscale " + codiceFiscale2 + " non è associato a nessun giocatore del sistema");
                return;
            }
            //Verifico che la partita non duri più del dovuto e che la stanza sia libera per quello slot temporale
            //Altrimenti chiedo all'Utente di inserire dei dati fino a quando non sono corretti
            while(!esitoDurata || !stanzaLibera){
                System.out.println("Inserisci il numero della stanza che vuoi prenotare");
                stampaListaStanze();
                idStanza = Integer.parseInt(tastiera.readLine());
                System.out.println("Inserisci la data nel formato gg/MM/yyyy");
                dataPrenotazione = LocalDate.parse(tastiera.readLine(), dateFormatter);
                System.out.println("Inserisci l'orario di inizio della partita nel formato HH:mm");
                tempoInizio = LocalTime.parse(tastiera.readLine(), timeFormatter);
                System.out.println("Inserisci l'orario di fine della partita nel formato HH:mm");
                tempoFine = LocalTime.parse(tastiera.readLine(), timeFormatter);
                esitoDurata = checkDurata(tempoInizio, tempoFine);
                stanzaLibera = checkStanzaLibera(idStanza, dataPrenotazione,tempoInizio);
            }

            //Gestione noleggio attrezzatura
            System.out.println("Vuoi noleggiare dell'attrezzatura o comprare degli indizi? true/false");
            boolean richiestaAttrezzatura = Boolean.parseBoolean(tastiera.readLine());
            Attrezzatura attrezzaturaNoleggiata = new Attrezzatura(0,0);
            if(richiestaAttrezzatura){
                System.out.println("Inserisci il numero di torce che vuoi noleggiare");
                int numeroTorce = Integer.parseInt(tastiera.readLine());
                System.out.println("Inserisci il numero di indizi che vuoi acquistare");
                int numeroIndizi = Integer.parseInt(tastiera.readLine());
                boolean attrezzaturaDisponibile = checkAttrezzatura(dataPrenotazione, numeroTorce, numeroIndizi);
                if(!attrezzaturaDisponibile){
                    System.out.println("Inserisci 1 per continuare con la prenotazione senza prenotare attrezzatura, altrimenti un qualsiasi numero per annullare");
                    if(Integer.parseInt(tastiera.readLine())!=1){
                        return;
                    }
                } else {
                    attrezzaturaNoleggiata.setNumeroTorce(numeroTorce);
                    attrezzaturaNoleggiata.setNumeroIndizi(numeroIndizi);
                    Magazzino richiesta = new Magazzino(dataPrenotazione, numeroTorce, numeroIndizi);
                    salvaRichiestaSuFile(richiesta);
                    listaRichieste.clear();
                    loadRichieste();
                }
            }
            //I dati sono validi ed esiste uno slot temporale corretto
            int idPrenotazione = 999;
            Stanza stanzaPrenotata = getStanzaId(idStanza);
            Giocatore primoGiocatore = getUtenteCodiceFiscale(codiceFiscale1);
            Giocatore secondoGiocatore = getUtenteCodiceFiscale(codiceFiscale2);
            float durataPartita = tempoInizio.until(tempoFine, ChronoUnit.HOURS);
            float prezzo = prospettoPrezzo(stanzaPrenotata, attrezzaturaNoleggiata, durataPartita);
            idPrenotazione = (listaPrenotazioni.getLast().getIdPrenotazione())+1;
            Prenotazione nuovaPrenotazione = new Prenotazione(idPrenotazione, stanzaPrenotata, primoGiocatore, secondoGiocatore, dataPrenotazione, tempoInizio, tempoFine, attrezzaturaNoleggiata, prezzo);
            listaPrenotazioni.add(nuovaPrenotazione);
            salvaPrenotazioneSuFile(nuovaPrenotazione);
            listaPrenotazioni.clear();
            loadPrenotazioni();

        }catch (IOException e){
            System.out.println("Si è verificato un errore nell'inserimento: " + e);
        }
    }
    //UC3
    public void modificaPrenotazione(){
        try{
            boolean validita = true;
            System.out.println("Inserisci l'id della prenotazione che vuoi modificare");
            int idPrenotazioneScelta = Integer.parseInt(tastiera.readLine());
            Prenotazione prenotazioneDaModificare = getPrenotazioneId(idPrenotazioneScelta);
            if(prenotazioneDaModificare==null){
                System.out.println("La prenotazione scelta non esiste");
                return;
            }
            System.out.println("Prenotazione scelta:");
            System.out.println(prenotazioneDaModificare);
            Magazzino richiestaDaModificare = getRichiesta(prenotazioneDaModificare.getDataPrenotazione(), prenotazioneDaModificare.getAttrezzaturaRichiesta().getNumeroTorce(), prenotazioneDaModificare.getAttrezzaturaRichiesta().getNumeroIndizi());

            //Rimuovo i dati per considerare la prenotazione attuale nulla
            listaPrenotazioni.remove(prenotazioneDaModificare);
            if(richiestaDaModificare!=null)
                listaRichieste.remove(richiestaDaModificare);

            //Inserisco i nuovi dati
            System.out.println("Inserisci l'id della stanza");
            int stanzaNuovo = Integer.parseInt(tastiera.readLine());
            System.out.println("Inserisci la nuova data dd/MM/yyyy");
            LocalDate dataNuovo = LocalDate.parse(tastiera.readLine(), dateFormatter);
            System.out.println("Inserisci la data di inizio HH:mm, durata massima partita 90 min");
            LocalTime inizioNuovo = LocalTime.parse(tastiera.readLine(), timeFormatter);
            System.out.println("Inserisci la data di fine HH:mm, durata massima partita 90 min");
            LocalTime fineNuovo = LocalTime.parse(tastiera.readLine(), timeFormatter);
            System.out.println("Inserisci il numero di torce");
            int torceNuovo = Integer.parseInt(tastiera.readLine());
            System.out.println("Inserisci il numero di indizi");
            int indiziNuovo = Integer.parseInt(tastiera.readLine());
            float durataNuova = inizioNuovo.until(fineNuovo, ChronoUnit.HOURS);
            //Verifico che le modifiche alla prenotazione siano valide
            if(!checkDurata(inizioNuovo, fineNuovo)){
                System.out.println("La durata deve essere massimo 90 minuti, ritorno al menu");
                validita = false;
            }
            if(!checkStanzaLibera(stanzaNuovo, dataNuovo, inizioNuovo)){
                System.out.println("Impossibile modificare la prenotazione, la stanza scelta nel periodo inserito è occupata");
                validita = false;
            }
            if(!checkAttrezzatura(dataNuovo, torceNuovo, indiziNuovo)){
                System.out.println("Impossibile modificare la prenotazione, attrezzature non disponibili");
                validita = false;
            }

            if(validita){
                //Elimino i dati vecchi dal file
                rimuoviPrenotazioneDaFile(prenotazioneDaModificare);
                if(richiestaDaModificare!=null)
                    rimuoviRichiestaDaFile(richiestaDaModificare);
                //A questo punto la prenotazione dovrebbe poter essere modificata e aggiornata
                richiestaDaModificare = new Magazzino(dataNuovo, torceNuovo, indiziNuovo);
                prenotazioneDaModificare.setStanzaScelta(getStanzaId(stanzaNuovo));
                prenotazioneDaModificare.setDataPrenotazione(dataNuovo);
                prenotazioneDaModificare.setOraInizio(inizioNuovo);
                prenotazioneDaModificare.setOraFine(fineNuovo);
                prenotazioneDaModificare.getAttrezzaturaRichiesta().setNumeroTorce(torceNuovo);
                prenotazioneDaModificare.getAttrezzaturaRichiesta().setNumeroIndizi(indiziNuovo);
                float prezzoNuovo = prospettoPrezzo(getStanzaId(stanzaNuovo), prenotazioneDaModificare.getAttrezzaturaRichiesta(), durataNuova);
                prenotazioneDaModificare.setCosto(prezzoNuovo);
                salvaPrenotazioneSuFile(prenotazioneDaModificare);
                if(torceNuovo+indiziNuovo>0){
                    listaRichieste.add(richiestaDaModificare);
                    salvaRichiestaSuFile(richiestaDaModificare);
                }
            }
            listaPrenotazioni.add(prenotazioneDaModificare);
        }catch(IOException e){
            System.out.println(e);
        }
    }
    //UC3
    public float rimuoviPrenotazione(){
        try{
            System.out.println("Inserisci l'id della prenotazione che vuoi annullare");
            int idPrenotazioneScelta = Integer.parseInt(tastiera.readLine());
            Prenotazione prenotazioneDaEliminare = getPrenotazioneId(idPrenotazioneScelta);
            if(prenotazioneDaEliminare==null){
                System.out.println("La prenotazione scelta non esiste");
                return 0.0f;
            }
            Magazzino richiestaDaEliminare = getRichiesta(prenotazioneDaEliminare.getDataPrenotazione(), prenotazioneDaEliminare.getAttrezzaturaRichiesta().getNumeroTorce(), prenotazioneDaEliminare.getAttrezzaturaRichiesta().getNumeroIndizi());
            float rimborso = prenotazioneDaEliminare.getCosto();
            LocalDate dataPrenotazione= prenotazioneDaEliminare.getDataPrenotazione();
            LocalTime inizioPrenotazione = prenotazioneDaEliminare.getOraInizio();
            if(!Objects.isNull(richiestaDaEliminare)){
                listaRichieste.remove(richiestaDaEliminare);
                rimuoviRichiestaDaFile(richiestaDaEliminare);
            }
            listaPrenotazioni.remove(prenotazioneDaEliminare);
            rimuoviPrenotazioneDaFile(prenotazioneDaEliminare);
            if(LocalDate.now().isEqual(dataPrenotazione)){
                if(LocalTime.now().until(inizioPrenotazione, ChronoUnit.HOURS)<48){
                    rimborso = 0.5f * rimborso;
                }
            }
            return rimborso;


        }catch (IOException e){
            System.out.println(e);
            return 0.0f;
        }
    }

    //Stampare a schermo elementi in memoria
    public void stampaListaGiocatori() {
        for (Giocatore giocatoreCorrente : listaGiocatori)
            System.out.println(giocatoreCorrente);
    }
    public void stampaListaStanze() {
        for (Stanza stanzaCorrente : listaStanze)
            System.out.println(stanzaCorrente);
    }
    public void stampaListaPrenotazioni(){
        for (Prenotazione prenotazioneCorrente : listaPrenotazioni)
            System.out.println(prenotazioneCorrente);
    }
    public void stampaListaRichieste(){
        for (Magazzino richiestaCorrente : listaRichieste)
            System.out.println(richiestaCorrente);
    }

    //Ricerca dati
    public Giocatore getUtenteCodiceFiscale(String codiceFiscale){
        for(Giocatore giocatoreCorrente : listaGiocatori){
            if(Objects.equals(giocatoreCorrente.getCodiceFiscale(), codiceFiscale)){
                return giocatoreCorrente;
            }
        }
        return null;
    }
    public Stanza getStanzaId(int idStanza){
        for(Stanza stanzaCorrente : listaStanze){
            if(Objects.equals(stanzaCorrente.getNumero(), idStanza)){
                return stanzaCorrente;
            }
        }
        return null;
    }
    public Prenotazione getPrenotazioneId (int idPrenotazione){
        for(Prenotazione prenotazioneCorrente : listaPrenotazioni){
            if(Objects.equals(prenotazioneCorrente.getIdPrenotazione(), idPrenotazione)){
                return prenotazioneCorrente;
            }
        }
        return null;
    }
    public Magazzino getRichiesta (LocalDate dataPrenotazione, int numeroTorce, int numeroIndizi){
        for(Magazzino richiestaCorrente : listaRichieste){
            if(dataPrenotazione.isEqual(richiestaCorrente.getDataPartita()) && (numeroTorce == richiestaCorrente.getNumeroTorce()) && (numeroIndizi== richiestaCorrente.getNumeroIndizi())){
                return richiestaCorrente;
            }
        }
        return null;
    }

    //Persistenza dei dati
    private void salvaGiocatoreSuFile(Giocatore giocatoreDaSalvare) {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter("listagiocatori.txt", true));
            String riga = giocatoreDaSalvare.getNome() + "," + giocatoreDaSalvare.getCognome() + "," + giocatoreDaSalvare.getCodiceFiscale() + "," + giocatoreDaSalvare.getEmail() + "," + (giocatoreDaSalvare.getDataNascita()).format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            writer.newLine();
            writer.write(riga);
            writer.close();
            System.out.println("Giocatore salvato su file con successo.");
        } catch (IOException e) {
            System.out.println("Si è verificato un errore nel file");
        }
    }
    public void rimuoviGiocatoreDaFile(String codiceFiscale){
        LinkedList<String> righeDaScrivere = new LinkedList<>();
        try{
            BufferedReader reader = new BufferedReader(new FileReader("listagiocatori.txt"));
            String rigaLetta;
            while ((rigaLetta = reader.readLine()) != null) {
                if(!rigaLetta.isEmpty()){
                    String[] campi = rigaLetta.split(",");
                    String codiceFiscaleLetto = campi[2];
                    if (!codiceFiscaleLetto.equals(codiceFiscale)) {
                        righeDaScrivere.add(rigaLetta);
                    }
                }
            }
            reader.close();

            BufferedWriter writer = new BufferedWriter(new FileWriter("listagiocatori.txt"));
            for (String rigaCorrente : righeDaScrivere) {
                writer.write(rigaCorrente);
                writer.newLine();
            }
            writer.close();
            loadUtentiRegistrati();
        }catch (IOException e){
            System.out.println("Si è verificato un errore nella rimozione del giocatore dal sistema");
        }
    }
    private void salvaPrenotazioneSuFile(Prenotazione prenotazioneDaSalvare){
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter("listaprenotazioni.txt", true));
            String riga = prenotazioneDaSalvare.getIdPrenotazione() + "," + prenotazioneDaSalvare.getIdStanza().getNumero() + "," + prenotazioneDaSalvare.getGiocatore1().getCodiceFiscale() + "," + prenotazioneDaSalvare.getGiocatore2().getCodiceFiscale() + "," + prenotazioneDaSalvare.getDataPrenotazione().format(dateFormatter) + "," + prenotazioneDaSalvare.getOraInizio().format(timeFormatter) + "," + prenotazioneDaSalvare.getOraFine().format(timeFormatter) + "," + prenotazioneDaSalvare.getAttrezzaturaRichiesta().getNumeroTorce() + "," + prenotazioneDaSalvare.getAttrezzaturaRichiesta().getNumeroIndizi() + "," + prenotazioneDaSalvare.getCosto();
            writer.newLine();
            writer.write(riga);
            writer.close();
            System.out.println("Prenotazione salvata su file con successo.");
        } catch (IOException e) {
            System.out.println("Si è verificato un errore nel file");
        }
    }
    public void rimuoviPrenotazioneDaFile(Prenotazione prenotazioneDaRimuovere) {
        LinkedList<String> righeDaMantenere = new LinkedList<>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader("listaprenotazioni.txt"));
            String riga;
            while ((riga = reader.readLine()) != null) {
                if(!riga.isEmpty()){
                    String[] campi = riga.split(",");
                    int idPrenotazione = Integer.parseInt(campi[0]);
                    if (idPrenotazione != prenotazioneDaRimuovere.getIdPrenotazione()) {
                        righeDaMantenere.add(riga);
                    }
                }

            }
            reader.close();

            BufferedWriter writer = new BufferedWriter(new FileWriter("listaprenotazioni.txt"));
            for (String rigaDaScrivere : righeDaMantenere) {
                writer.write(rigaDaScrivere);
                writer.newLine();
            }
            writer.close();

        } catch (IOException e) {
            System.out.println("Errore durante la rimozione della prenotazione dal file: " + e);

        }
    }
    private void rimuoviRichiestaDaFile (Magazzino richiestaDaRimuovere){
        LinkedList<String> righeDaMantenere = new LinkedList<>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader("listarichieste.txt"));
            String riga;
            LocalDate dataRichiesta = richiestaDaRimuovere.getDataPartita();
            int torceRichiesta = richiestaDaRimuovere.getNumeroTorce();
            int indiziRichiesta = richiestaDaRimuovere.getNumeroIndizi();
            while ((riga = reader.readLine()) != null) {
                if(!riga.isEmpty()){
                    String[] campi = riga.split(",");
                    LocalDate dataFile = LocalDate.parse(campi[0], dateFormatter );
                    int torceFile = Integer.parseInt(campi[1]);
                    int indiziFile = Integer.parseInt(campi[2]);
                    if(torceRichiesta==torceFile && indiziRichiesta==indiziFile && dataRichiesta.isEqual(dataFile)){
                        System.out.println("Corrispondenza trovata");
                    }else{
                        righeDaMantenere.add(riga);
                    }
                }
            }
            reader.close();

            BufferedWriter writer = new BufferedWriter(new FileWriter("listarichieste.txt"));
            for (String rigaDaScrivere : righeDaMantenere) {
                writer.write(rigaDaScrivere);
                writer.newLine();
            }
            writer.close();

        } catch (IOException e) {
            System.out.println("Errore durante la rimozione della prenotazione dal file: " + e);

        }
    }
    private void salvaRichiestaSuFile(Magazzino richiestaDaSalvare){
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter("listarichieste.txt", true));
            String riga = richiestaDaSalvare.getDataPartita().format(dateFormatter) + "," + richiestaDaSalvare.getNumeroTorce() + "," + richiestaDaSalvare.getNumeroIndizi();
            writer.newLine();
            writer.write(riga);
            writer.close();
            System.out.println("Richiesta salvata su file con successo.");
        } catch (IOException e) {
            System.out.println("Si è verificato un errore nel file");
        }
    }

    //Logica metodi
    private boolean verificaValiditaGiocatore(String codiceFiscale){
        boolean esito = true;
        Giocatore giocatoreCorrente = getUtenteCodiceFiscale(codiceFiscale);
        if(Objects.isNull(giocatoreCorrente))
            esito = false;
        return esito;
    }
    private boolean checkDurata(LocalTime inizio, LocalTime fine){
        boolean esito = true;
        long differenza = inizio.until(fine, ChronoUnit.MINUTES);
        if (differenza>limite){
            esito=false;
            System.out.println("Una stanza può essere prenotata per " + limite + " minuti consecutivi");
        }
        return esito;
    }
    private boolean checkStanzaLibera(int stanzaPrenotazione, LocalDate dataPrenotazione, LocalTime inizioPrenotazione){
        boolean esito = true;
        for(Prenotazione prenotazioneSalvata : listaPrenotazioni){
            if((prenotazioneSalvata.getIdStanza().getNumero() == stanzaPrenotazione) && prenotazioneSalvata.getDataPrenotazione().isEqual(dataPrenotazione)){
                if(inizioPrenotazione.isBefore(prenotazioneSalvata.getOraFine())){
                    System.out.println("La stanza non è libera nell'intervallo di tempo scelto");
                    esito = false;
                }
            }
        }
        return esito;
    }
    private boolean checkAttrezzatura(LocalDate giornoPartita, int torceRichieste, int indiziRichiesti){
        boolean esito = true;
        int torceImpegnate = 0;
        int indiziImpegnati = 0;
        int totaleTorce;
        int totaleIndizi;
        for(Magazzino richiestaCorrente: listaRichieste){
            if((richiestaCorrente.getDataPartita().isEqual(giornoPartita))&&(richiestaCorrente.getDataPartita().isAfter(LocalDate.now()))){
                torceImpegnate = torceImpegnate + richiestaCorrente.getNumeroTorce();
                indiziImpegnati = indiziImpegnati + richiestaCorrente.getNumeroIndizi();
            }
        }
        totaleTorce = torceImpegnate + torceRichieste;
        totaleIndizi = indiziImpegnati + indiziRichiesti;
        if((totaleTorce > massimoTorce) || (totaleIndizi > massimoIndizi)){
            System.out.println("Non sono disponibili sufficienti torce/indizi!");
            esito = false;
        }
        return esito;
    }
    private float prospettoPrezzo(Stanza stanzaPrenotata, Attrezzatura attrezzaturaNoleggiata, float durataPartita){
        float prezzoStanza = stanzaPrenotata.getPrezzo() * durataPartita;
        float prezzoAttrezzatura= (attrezzaturaNoleggiata.getNumeroTorce() + attrezzaturaNoleggiata.getNumeroIndizi()) * costoAttrezzo;
        return prezzoStanza + prezzoAttrezzatura;
    }

    //Funzioni per test

    public LinkedList<Giocatore> getListaGiocatori(){
        return listaGiocatori;
    }
    public LinkedList<Stanza> getListaStanze() {
        return listaStanze;
    }
    public LinkedList<Prenotazione> getListaPrenotazioni(){
        return listaPrenotazioni;
    }
}

