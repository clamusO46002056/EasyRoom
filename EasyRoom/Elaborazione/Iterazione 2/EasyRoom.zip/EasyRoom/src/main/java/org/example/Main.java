package org.example;
import java.io.*;

public class Main {
    public static void main(String[] args) {
        //MAIN
        BufferedReader tastiera;
        tastiera = new BufferedReader(new InputStreamReader((System.in)));
        EasyRoom applicazione = EasyRoom.getInstance(); //Pattern GoF Singleton
        System.out.println("Sei un amministratore? true/false");
        //Pattern Gof Facade
        try{
            boolean admin = Boolean.parseBoolean(tastiera.readLine());
            if(admin){
                applicazioneAdmin(applicazione, tastiera);
            } else {
                applicazioneUtente(applicazione, tastiera);
            }
        } catch (IOException e){
            System.out.println(e);
        }
    }
    public static void applicazioneAdmin(EasyRoom applicazione, BufferedReader tastiera){
        try{
            int scelta;
            while(true){
                System.out.println("\n");
                System.out.println("---------------------------EasyRoom (Admin Version)----------------------------------------");
                System.out.println("Inserisci un numero per eseguire una tra le seguenti operazioni");
                System.out.println("1) Inserisci un nuovo giocatore (UC1)");
                System.out.println("2) Effettua una prenotazione (UC2) ");
                System.out.println("3) Modifica o annulla una prenotazione (UC3)");
                System.out.println("4) Visualizza le prenotazioni (UC4)");
                System.out.println("5) Conteggio partite per una stanza (UC5)");
                System.out.println("6) Modifica una stanza (UC6)");
                System.out.println("7) Gestione del magazzino (UC7)");
                System.out.println("8) Stampa lista giocatori");
                System.out.println("9) Stampa lista prenotazioni");
                System.out.println("10) Stampa lista richieste");
                System.out.println("0) Per terminare l'esecuzione");
                scelta=Integer.parseInt(tastiera.readLine());
                switch(scelta){
                    case 1:
                        applicazione.inserisciUtente();
                        break;
                    case 2:
                        applicazione.inserisciPrenotazione();
                        break;
                    case 3:
                        System.out.println("Hai scelto 3");
                        break;
                    case 4:
                        System.out.println("Hai scelto 4");
                        break;
                    case 5:
                        System.out.println("Hai scelto 5");
                        break;
                    case 6:
                        System.out.println("Hai scelto 6");
                        applicazione.stampaListaStanze();
                        break;
                    case 7:
                        System.out.println("Hai scelto 7");
                        break;
                    case 8:
                        applicazione.stampaListaGiocatori();
                        break;
                    case 9:
                        applicazione.stampaListaPrenotazioni();
                        break;
                    case 10:
                        applicazione.stampaListaRichieste();
                        break;
                    case 0:
                        return;
                    default:
                        System.out.println("Scelta non valida, riprovare");
                        break;
                }
            }
        }catch(Exception e){
            System.out.println("Si è verificato un errore nell'inserimento della scelta" + e);
        }
    }
    public static void applicazioneUtente(EasyRoom applicazione, BufferedReader tastiera){
        try{
            int scelta;
            while(true){
                System.out.println("\n");
                System.out.println("---------------------------EasyRoom (User Version)----------------------------------------");
                System.out.println("Inserisci un numero per eseguire una tra le seguenti operazioni");
                System.out.println("1) Effettua una prenotazione (UC2) ");
                System.out.println("2) Modifica o annulla una prenotazione (UC3)");
                System.out.println("0) Per terminare l'esecuzione");
                scelta=Integer.parseInt(tastiera.readLine());
                switch(scelta){

                    case 1:
                        applicazione.inserisciPrenotazione();
                        break;
                    case 2:
                        System.out.println("1)Annulla una prenotazione");
                        System.out.println("2)Modifica una prenotazione");
                        int azione = Integer.parseInt(tastiera.readLine());
                        applicazione.stampaListaPrenotazioni();
                        switch (azione){
                            case 1:
                                float rimborso = applicazione.rimuoviPrenotazione();
                                System.out.println("Hai ottenuto un rimborso di euro " + rimborso);
                                break;
                            case 2:
                                applicazione.modificaPrenotazione();
                                break;
                        }
                        break;
                    case 0:
                        return;
                    default:
                        System.out.println("Scelta non valida, riprovare");
                        break;
                }
            }
        }catch(Exception e){
            System.out.println("Si è verificato un errore nell'inserimento della scelta" + e);
        }
    }
}