package org.example;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Magazzino {
    DateTimeFormatter customFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private int numeroTorce;
    private int numeroIndizi;
    private LocalDate dataPartita;
    public Magazzino (LocalDate dataPartita, int torceRichieste, int indiziRichiesti){
        this.numeroTorce=torceRichieste;
        this.numeroIndizi=indiziRichiesti;
        this.dataPartita=dataPartita;
    }

    public int getNumeroIndizi() {
        return numeroIndizi;
    }
    public int getNumeroTorce() {
        return numeroTorce;
    }
    public void setNumeroIndizi(int numeroIndizi) {
        this.numeroIndizi = numeroIndizi;
    }
    public void setNumeroTorce(int numeroTorce) {
        this.numeroTorce = numeroTorce;
    }
    public LocalDate getDataPartita() {
        return dataPartita;
    }
    public void setDataPartita(LocalDate dataPartita) {
        this.dataPartita = dataPartita;
    }

    @Override
    public String toString(){
        return "Data prenotazione: " + dataPartita.format(customFormatter) + ", numero torce: " + numeroTorce + ", numero indizi: " + numeroIndizi;
    }
}
